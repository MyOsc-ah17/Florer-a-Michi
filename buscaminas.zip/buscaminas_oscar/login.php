<div class="IngresarDatos" method="post" action="">
   <h3 class="title1">Busca minas PHP</h3>
   <h3 class="title1">Ingrese Name Player y N</h3>
  <input class="input"type="text" name="nameJ" id="nameJ"  value="" placeholder="Name Player" required/>  
  <input class="input"type="text" name="valorN" id="valorN"  value="" placeholder="valor 8<=N<=20" required/> 
  <input class="input"type="submit" name="Boton" id="button" value="Aceptar" />
</div>
<?php
$_SESSION["estado"]=2;
?>